## Fras
A Payment Gateway built with Vanilla Node.js and MongoDB as a School Coursework

To use, please create a database called "MagPay".
Then, to have user login, please a collection called "users" need to be created in the database.
And a "username" field needs to contain "Saviour" and "password" field with data as "Fras".

```
use MagPay;
db.createCollection("users);
db.users.insertOne({"username":"Saviour", "password":"Fras"});
```
